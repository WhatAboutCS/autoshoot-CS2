﻿; 
P::Suspend

; 
~$*LButton::
    While GetKeyState("LButton", "P")
    {
        Click
        Sleep 1  ; 
    }
Return